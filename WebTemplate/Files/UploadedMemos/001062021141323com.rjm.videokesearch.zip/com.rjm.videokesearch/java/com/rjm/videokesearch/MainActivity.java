package com.rjm.videokesearch;

import adrt.ADRTLogCatReader;
import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.app.ActionBar.Tab;
import android.app.ActionBar.TabListener;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Build.VERSION;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.SimpleOnPageChangeListener;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.SearchView.OnQueryTextListener;
import com.rjm.videokesearch.DatabaseHelper;
import com.rjm.videokesearch.FaveListViewAdapter;
import com.rjm.videokesearch.ListViewAdapter;
import java.io.File;
import java.util.ArrayList;

public class MainActivity extends FragmentActivity implements TabListener {
   static DatabaseHelper myDbHelper;
   ListViewAdapter adapter;
   ArrayList arraylist;
   private boolean doubleBackToExitPressedOnce;
   FaveListViewAdapter faveadapter;
   ArrayList favearraylist;
   String fileName = "";
   File folder;
   boolean isSearchActive;
   ListView list;
   MainActivity.AppSectionsPagerAdapter mAppSectionsPagerAdapter;
   ViewPager mViewPager;
   String path = "";
   String search = "";
   SearchView searchView;
   SearchView searchViewFaves;
   ArrayAdapter spinneritem;
   Spinner spnrFavesSearchBy;
   Spinner spnrSearchBy;
   String text = "";
   File txtDb;

   public MainActivity() {
      ArrayList var1 = new ArrayList();
      this.arraylist = var1;
      ArrayList var2 = new ArrayList();
      this.favearraylist = var2;
      this.doubleBackToExitPressedOnce = false;
   }

   // $FF: synthetic method
   static boolean access$L1000000(MainActivity var0) {
      return var0.doubleBackToExitPressedOnce;
   }

   public void getAllFavorites() {
      // $FF: Couldn't be decompiled
   }

   public void getAllSongs() {
      // $FF: Couldn't be decompiled
   }

   public void onBackPressed() {
      if(this.doubleBackToExitPressedOnce) {
         super.onBackPressed();
      } else {
         this.doubleBackToExitPressedOnce = true;
         Toast.makeText(this, "Press again to exit", 0).show();
         Handler var1 = new Handler();
         MainActivity.100000005 var2 = new MainActivity.100000005();
         var1.postDelayed(var2, (long)2000);
      }
   }

   @Override
   protected void onCreate(Bundle var1) {
      ADRTLogCatReader.onContext(this, "com.aide.ui");
      super.onCreate(var1);
      this.setContentView(2130903041);
      if(this != null) {
         try {
            DatabaseHelper var11 = new DatabaseHelper(this);
            myDbHelper = var11;
         } catch (Exception var15) {
            Context var13 = this.getBaseContext();
            StringBuffer var14 = new StringBuffer();
            Toast.makeText(var13, var14.append("DbHelper error: ").append(var15.getMessage()).toString(), 0).show();
         }
      }

      MainActivity.AppSectionsPagerAdapter var2 = new MainActivity.AppSectionsPagerAdapter(this.getSupportFragmentManager());
      this.mAppSectionsPagerAdapter = var2;
      ArrayAdapter var3 = new ArrayAdapter(this, 2130903046);
      this.spinneritem = var3;
      ActionBar var4 = this.getActionBar();
      ColorDrawable var5 = new ColorDrawable(Color.parseColor("#FF008F4D"));
      var4.setBackgroundDrawable(var5);
      if(VERSION.SDK_INT >= 21) {
         Window var10 = this.getWindow();
         var10.addFlags(Integer.MIN_VALUE);
         var10.clearFlags(67108864);
         var10.setStatusBarColor(Color.parseColor("#FF00714D"));
         var10.setTitleColor(Color.parseColor("#FFFFFFFF"));
      }

      var4.setHomeButtonEnabled(false);
      var4.setNavigationMode(2);
      this.mViewPager = (ViewPager)this.findViewById(2131165190);
      this.mViewPager.setAdapter(this.mAppSectionsPagerAdapter);
      ViewPager var6 = this.mViewPager;
      MainActivity.100000000 var7 = new MainActivity.100000000(var4);
      var6.setOnPageChangeListener(var7);

      for(int var8 = 0; var8 < this.mAppSectionsPagerAdapter.getCount(); ++var8) {
         String var9 = "";
         switch(var8) {
         case 0:
            var9 = "Search";
            break;
         case 1:
            var9 = "Favorites";
         }

         var4.addTab(var4.newTab().setText(var9).setTabListener(this));
      }

   }

   public void onCreateContextMenu(ContextMenu var1, View var2, ContextMenuInfo var3) {
   }

   @Override
   public boolean onCreateOptionsMenu(Menu var1) {
      this.getMenuInflater().inflate(2131099649, var1);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem var1) {
      switch(var1.getItemId()) {
      case 2131165223:
         Context var2 = this.getApplicationContext();

         Class var5;
         try {
            var5 = Class.forName("com.rjm.videokesearch.About");
         } catch (ClassNotFoundException var19) {
            NoClassDefFoundError var4 = new NoClassDefFoundError(var19.getMessage());
            throw var4;
         }

         Intent var6 = new Intent(var2, var5);
         this.startActivity(var6);
         return true;
      case 2131165224:
         Context var7 = this.getApplicationContext();

         Class var10;
         try {
            var10 = Class.forName("com.rjm.videokesearch.About");
         } catch (ClassNotFoundException var18) {
            NoClassDefFoundError var9 = new NoClassDefFoundError(var18.getMessage());
            throw var9;
         }

         Intent var11 = new Intent(var7, var10);
         this.startActivity(var11);
         return true;
      case 2131165225:
         Builder var12 = new Builder(this);
         var12.setTitle("");
         Builder var14 = var12.setMessage("Are you sure you want to exit?").setCancelable(false);
         MainActivity.100000006 var15 = new MainActivity.100000006();
         Builder var16 = var14.setPositiveButton("Yes", var15);
         MainActivity.100000007 var17 = new MainActivity.100000007();
         var16.setNegativeButton("No", var17);
         var12.create().show();
         return true;
      default:
         return super.onOptionsItemSelected(var1);
      }
   }

   @Override
   public void onTabReselected(Tab var1, FragmentTransaction var2) {
   }

   @Override
   public void onTabSelected(Tab var1, FragmentTransaction var2) {
      this.mViewPager.setCurrentItem(var1.getPosition());
   }

   @Override
   public void onTabUnselected(Tab var1, FragmentTransaction var2) {
   }

   class 100000000 extends SimpleOnPageChangeListener {
      private final ActionBar val$actionBar;

      _00000000/* $FF was: 100000000*/(ActionBar var2) {
         this.val$actionBar = var2;
      }

      static MainActivity access$0(MainActivity.100000000 var0) {
         return MainActivity.this;
      }

      @Override
      public void onPageSelected(int var1) {
         this.val$actionBar.setSelectedNavigationItem(var1);
      }
   }

   class 100000001 implements OnItemSelectedListener {
      static MainActivity access$0(MainActivity.100000001 var0) {
         return MainActivity.this;
      }

      public void onItemSelected(AdapterView var1, View var2, int var3, long var4) {
         MainActivity.this.search = MainActivity.this.spnrSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchView.getQuery().toString();
         MainActivity.this.adapter.filter(MainActivity.this.text, MainActivity.this.search);
      }

      public void onNothingSelected(AdapterView var1) {
      }
   }

   class 100000002 implements OnQueryTextListener {
      static MainActivity access$0(MainActivity.100000002 var0) {
         return MainActivity.this;
      }

      @Override
      public boolean onQueryTextChange(String var1) {
         MainActivity.this.search = MainActivity.this.spnrSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchView.getQuery().toString();
         MainActivity.this.adapter.filter(MainActivity.this.text, MainActivity.this.search);
         return false;
      }

      @Override
      public boolean onQueryTextSubmit(String var1) {
         MainActivity.this.search = MainActivity.this.spnrSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchView.getQuery().toString();
         MainActivity.this.adapter.filter(MainActivity.this.text, MainActivity.this.search);
         return false;
      }
   }

   class 100000003 implements Runnable {
      static MainActivity access$0(MainActivity.100000003 var0) {
         return MainActivity.this;
      }

      @Override
      public void run() {
         MainActivity.this.doubleBackToExitPressedOnce = false;
      }
   }

   class 100000004 implements OnClickListener {
      static MainActivity access$0(MainActivity.100000004 var0) {
         return MainActivity.this;
      }

      public void onClick(DialogInterface var1, int var2) {
         MainActivity.this.finish();
      }
   }

   class 100000005 implements Runnable {
      static MainActivity access$0(MainActivity.100000005 var0) {
         return MainActivity.this;
      }

      @Override
      public void run() {
         MainActivity.this.doubleBackToExitPressedOnce = false;
      }
   }

   class 100000006 implements OnClickListener {
      static MainActivity access$0(MainActivity.100000006 var0) {
         return MainActivity.this;
      }

      public void onClick(DialogInterface var1, int var2) {
         MainActivity.this.finish();
      }
   }

   class 100000007 implements OnClickListener {
      static MainActivity access$0(MainActivity.100000007 var0) {
         return MainActivity.this;
      }

      public void onClick(DialogInterface var1, int var2) {
         var1.cancel();
      }
   }

   public class AppSectionsPagerAdapter extends FragmentPagerAdapter {
      public AppSectionsPagerAdapter(FragmentManager var2) {
         super(var2);
      }

      static MainActivity access$0(MainActivity.AppSectionsPagerAdapter var0) {
         return MainActivity.this;
      }

      @Override
      public int getCount() {
         return 2;
      }

      @Override
      public Fragment getItem(int var1) {
         switch(var1) {
         case 0:
            MainActivity.SearchSectionFragment var3 = MainActivity.this.new SearchSectionFragment();
            return var3;
         case 1:
            MainActivity.FaveSectionFragment var2 = MainActivity.this.new FaveSectionFragment();
            return var2;
         default:
            MainActivity.FaveSectionFragment var4 = MainActivity.this.new FaveSectionFragment();
            return var4;
         }
      }

      @Override
      public CharSequence getPageTitle(int var1) {
         StringBuffer var2 = new StringBuffer();
         return var2.append("Section ").append(var1 + 1).toString();
      }
   }

   public class DummySectionFragment extends Fragment {
      static MainActivity access$0(MainActivity.DummySectionFragment var0) {
         return MainActivity.this;
      }

      @Override
      public View onCreateView(LayoutInflater var1, ViewGroup var2, Bundle var3) {
         View var4 = var1.inflate(2130903042, var2, false);
         MainActivity.this.list = (ListView)var4.findViewById(2131165191);
         return var4;
      }
   }

   public class FaveSectionFragment extends Fragment {
      @Override
      public View onCreateView(LayoutInflater var1, ViewGroup var2, Bundle var3) {
         View var4 = var1.inflate(2130903043, var2, false);
         MainActivity.this.list = (ListView)var4.findViewById(2131165195);
         MainActivity var5 = MainActivity.this;
         FaveListViewAdapter var6 = new FaveListViewAdapter(MainActivity.this, MainActivity.this.favearraylist);
         var5.faveadapter = var6;
         MainActivity.this.list.setAdapter(MainActivity.this.faveadapter);
         MainActivity.this.spnrFavesSearchBy = (Spinner)var4.findViewById(2131165193);
         MainActivity.this.spnrFavesSearchBy.setElevation((float)2);
         MainActivity.this.spinneritem.clear();
         MainActivity.this.spnrFavesSearchBy.setAdapter(MainActivity.this.spinneritem);
         MainActivity.this.spinneritem.add("Search By");
         MainActivity.this.spinneritem.add("Song");
         MainActivity.this.spinneritem.add("Singer");
         MainActivity.this.spinneritem.add("Category");
         Spinner var7 = MainActivity.this.spnrFavesSearchBy;
         MainActivity.100000003 var8 = new MainActivity.100000003();
         var7.setOnItemSelectedListener(var8);
         MainActivity.this.searchViewFaves = (SearchView)var4.findViewById(2131165194);
         MainActivity.this.searchViewFaves.setElevation((float)2);
         SearchView var9 = MainActivity.this.searchViewFaves;
         MainActivity.100000004 var10 = new MainActivity.100000004();
         var9.setOnQueryTextListener(var10);
         return var4;
      }
   }

   class 100000003 implements OnItemSelectedListener {
      static MainActivity.FaveSectionFragment access$0(MainActivity.100000003 var0) {
         return MainActivity.this;
      }

      public void onItemSelected(AdapterView var1, View var2, int var3, long var4) {
         MainActivity.this.search = MainActivity.this.spnrFavesSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchViewFaves.getQuery().toString();
         MainActivity.this.faveadapter.filter(MainActivity.this.text, MainActivity.this.search);
      }

      public void onNothingSelected(AdapterView var1) {
      }
   }

   class 100000004 implements OnQueryTextListener {
      static MainActivity.FaveSectionFragment access$0(MainActivity.100000004 var0) {
         return MainActivity.this;
      }

      @Override
      public boolean onQueryTextChange(String var1) {
         MainActivity.this.search = MainActivity.this.spnrFavesSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchViewFaves.getQuery().toString();
         MainActivity.this.faveadapter.filter(MainActivity.this.text, MainActivity.this.search);
         return false;
      }

      @Override
      public boolean onQueryTextSubmit(String var1) {
         return false;
      }
   }

   public class LaunchpadSectionFragment extends Fragment {
      static MainActivity access$0(MainActivity.LaunchpadSectionFragment var0) {
         return MainActivity.this;
      }

      @Override
      public View onCreateView(LayoutInflater var1, ViewGroup var2, Bundle var3) {
         View var4 = var1.inflate(2130903044, var2, false);
         MainActivity.this.list = (ListView)var4.findViewById(2131165197);
         MainActivity var5 = MainActivity.this;
         ListViewAdapter var6 = new ListViewAdapter(MainActivity.this, MainActivity.this.arraylist);
         var5.adapter = var6;
         MainActivity.this.list.setAdapter(MainActivity.this.adapter);
         return var4;
      }
   }

   public class SearchSectionFragment extends Fragment {
      @Override
      public View onCreateView(LayoutInflater var1, ViewGroup var2, Bundle var3) {
         View var4 = var1.inflate(2130903045, var2, false);
         MainActivity.this.list = (ListView)var4.findViewById(2131165200);
         this.registerForContextMenu(MainActivity.this.list);
         MainActivity var5 = MainActivity.this;
         ListViewAdapter var6 = new ListViewAdapter(MainActivity.this, MainActivity.this.arraylist);
         var5.adapter = var6;
         MainActivity.this.list.setAdapter(MainActivity.this.adapter);
         MainActivity.this.spnrSearchBy = (Spinner)var4.findViewById(2131165198);
         MainActivity.this.spnrSearchBy.setElevation((float)2);
         MainActivity.this.spnrSearchBy.setAdapter(MainActivity.this.spinneritem);
         MainActivity.this.spinneritem.add("Search By");
         MainActivity.this.spinneritem.add("Song");
         MainActivity.this.spinneritem.add("Singer");
         MainActivity.this.spinneritem.add("Category");
         Spinner var7 = MainActivity.this.spnrSearchBy;
         MainActivity.100000001 var8 = new MainActivity.100000001();
         var7.setOnItemSelectedListener(var8);
         MainActivity.this.searchView = (SearchView)var4.findViewById(2131165199);
         MainActivity.this.searchView.setElevation((float)2);
         SearchView var9 = MainActivity.this.searchView;
         MainActivity.100000002 var10 = new MainActivity.100000002();
         var9.setOnQueryTextListener(var10);
         return var4;
      }
   }

   class 100000001 implements OnItemSelectedListener {
      static MainActivity.SearchSectionFragment access$0(MainActivity.100000001 var0) {
         return MainActivity.this;
      }

      public void onItemSelected(AdapterView var1, View var2, int var3, long var4) {
         MainActivity.this.search = MainActivity.this.spnrSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchView.getQuery().toString();
         MainActivity.this.adapter.filter(MainActivity.this.text, MainActivity.this.search);
      }

      public void onNothingSelected(AdapterView var1) {
      }
   }

   class 100000002 implements OnQueryTextListener {
      static MainActivity.SearchSectionFragment access$0(MainActivity.100000002 var0) {
         return MainActivity.this;
      }

      @Override
      public boolean onQueryTextChange(String var1) {
         MainActivity.this.search = MainActivity.this.spnrSearchBy.getSelectedItem().toString();
         MainActivity.this.text = MainActivity.this.searchView.getQuery().toString();
         MainActivity.this.adapter.filter(MainActivity.this.text, MainActivity.this.search);
         return false;
      }

      @Override
      public boolean onQueryTextSubmit(String var1) {
         return false;
      }
   }
}
