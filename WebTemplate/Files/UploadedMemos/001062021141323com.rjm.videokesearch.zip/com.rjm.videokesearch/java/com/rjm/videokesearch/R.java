package com.rjm.videokesearch;

public final class R {
   public static final class attr {
   }

   public static final class drawable {
      public static final int background = 2130837504;
      public static final int ic_clear = 2130837505;
      public static final int ic_fave_1 = 2130837506;
      public static final int ic_fave_2 = 2130837507;
      public static final int ic_launcher = 2130837508;
      public static final int ic_menu_dot = 2130837509;
      public static final int ic_menu_dot_white = 2130837510;
      public static final int ic_menu_square_black = 2130837511;
      public static final int ic_menu_square_gray = 2130837512;
      public static final int ic_search = 2130837513;
      public static final int ic_search_white = 2130837514;
      public static final int ic_videoke = 2130837515;
      public static final int ic_videoke_3 = 2130837516;
      public static final int ic_videoke_4 = 2130837517;
   }

   public static final class id {
      public static final int Category = 2131165210;
      public static final int Code = 2131165204;
      public static final int DetailsLayout = 2131165207;
      public static final int FaveButtonLayout = 2131165202;
      public static final int PopupMenuLayout = 2131165205;
      public static final int Singer = 2131165209;
      public static final int Song = 2131165208;
      public static final int SongLayoutMain = 2131165201;
      public static final int aboutAuthor = 2131165187;
      public static final int aboutBuild = 2131165186;
      public static final int aboutCreator = 2131165189;
      public static final int aboutLinearLayout1 = 2131165184;
      public static final int aboutTitle = 2131165185;
      public static final int aboutVersion = 2131165188;
      public static final int addtofavorite_item = 2131165221;
      public static final int artist = 2131165215;
      public static final int artistlabel = 2131165216;
      public static final int btnFavorite = 2131165203;
      public static final int btnPopupMenu = 2131165206;
      public static final int category = 2131165217;
      public static final int checkBoxFavorites = 2131165218;
      public static final int code = 2131165211;
      public static final int codelabel = 2131165212;
      public static final int delete_item = 2131165220;
      public static final int details_item = 2131165222;
      public static final int dummyListView = 2131165191;
      public static final int listView = 2131165197;
      public static final int listViewFaves = 2131165195;
      public static final int listViewSearch = 2131165200;
      public static final int menu_about = 2131165224;
      public static final int menu_exit = 2131165225;
      public static final int menu_settings = 2131165223;
      public static final int pager = 2131165190;
      public static final int searchView = 2131165199;
      public static final int searchViewFaves = 2131165194;
      public static final int searchWidgetLayout = 2131165192;
      public static final int spnrFavesSearchBy = 2131165193;
      public static final int spnrSearchBy = 2131165198;
      public static final int spnrSelectDatabase = 2131165196;
      public static final int title = 2131165213;
      public static final int titlelabel = 2131165214;
      public static final int update_item = 2131165219;
   }

   public static final class layout {
      public static final int about = 2130903040;
      public static final int activity_main = 2130903041;
      public static final int fragment_section_dummy = 2130903042;
      public static final int fragment_section_favorites = 2130903043;
      public static final int fragment_section_launchpad = 2130903044;
      public static final int fragment_section_search = 2130903045;
      public static final int list_item = 2130903046;
      public static final int listview_item = 2130903047;
      public static final int listview_item_favorites = 2130903048;
      public static final int searchview = 2130903049;
      public static final int settings = 2130903050;
      public static final int singleitemview = 2130903051;
   }

   public static final class menu {
      public static final int item_options = 2131099648;
      public static final int menu_options = 2131099649;
   }

   public static final class string {
      public static final int addtofavorite_item = 2130968585;
      public static final int app_name = 2130968576;
      public static final int delete_item = 2130968584;
      public static final int details_item = 2130968586;
      public static final int dummy_section_text = 2130968578;
      public static final int hello_world = 2130968577;
      public static final int menu_about = 2130968581;
      public static final int menu_exit = 2130968580;
      public static final int menu_search = 2130968582;
      public static final int menu_settings = 2130968579;
      public static final int update_item = 2130968583;
   }

   public static final class style {
      public static final int AppTheme = 2131034112;
   }
}
