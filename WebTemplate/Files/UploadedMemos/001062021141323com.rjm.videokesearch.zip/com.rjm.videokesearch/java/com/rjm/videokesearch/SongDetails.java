package com.rjm.videokesearch;

public class SongDetails {
   private String artist;
   private String category;
   private String code;
   private String title;

   public SongDetails(String var1, String var2, String var3, String var4) {
      this.code = var1;
      this.title = var2;
      this.artist = var3;
      this.category = var4;
   }

   public String getArtist() {
      return this.artist;
   }

   public String getCategory() {
      return this.category;
   }

   public String getCode() {
      return this.code;
   }

   public String getTitle() {
      return this.title;
   }
}
