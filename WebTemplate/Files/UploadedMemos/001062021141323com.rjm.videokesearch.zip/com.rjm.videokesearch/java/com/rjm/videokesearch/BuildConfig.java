package com.rjm.videokesearch;

public final class BuildConfig {
   public static final boolean DEBUG = true;
}
