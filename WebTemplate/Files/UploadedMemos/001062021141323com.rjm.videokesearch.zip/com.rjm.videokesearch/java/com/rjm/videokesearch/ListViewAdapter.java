package com.rjm.videokesearch;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.PopupMenu.OnMenuItemClickListener;
import com.rjm.videokesearch.MainActivity;
import com.rjm.videokesearch.Songs;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class ListViewAdapter extends BaseAdapter {
   private ArrayList arraylist;
   ImageButton btnFave;
   ImageButton btnPopupMenu;
   String category = "";
   String code = "";
   ArrayList favearraylist;
   File folder;
   FileOutputStream fos;
   ListViewAdapter.ViewHolder holder;
   int id;
   LayoutInflater inflater;
   int isFavorite = 0;
   Context mContext;
   String singer = "";
   String song = "";
   private List songlist;
   File txtDb;

   public ListViewAdapter(Context var1, List var2) {
      ArrayList var3 = new ArrayList();
      this.favearraylist = var3;
      this.songlist = (List)null;
      this.mContext = var1;
      this.songlist = var2;
      this.inflater = LayoutInflater.from(this.mContext);
      ArrayList var4 = new ArrayList();
      this.arraylist = var4;
      this.arraylist.addAll(var2);
   }

   public void filter(String var1, String var2) {
      String var3 = var1.toLowerCase(Locale.getDefault());
      this.songlist.clear();
      if(var3.length() == 0) {
         this.songlist.addAll(this.arraylist);
      } else if(var3.length() != 0 && var2.equals("Search By")) {
         Iterator var9 = ((Collection)this.arraylist).iterator();

         label51:
         while(true) {
            Songs var10;
            do {
               if(!var9.hasNext()) {
                  break label51;
               }

               var10 = (Songs)var9.next();
            } while(!var10.getSong().toLowerCase(Locale.getDefault()).contains(var3) && !var10.getSinger().toLowerCase(Locale.getDefault()).contains(var3) && !var10.getCategory().toLowerCase(Locale.getDefault()).contains(var3));

            this.songlist.add(var10);
         }
      } else {
         Iterator var4 = ((Collection)this.arraylist).iterator();

         while(var4.hasNext()) {
            Songs var5 = (Songs)var4.next();
            if(var5.getSong().toLowerCase(Locale.getDefault()).contains(var3) && var2.equals("Song")) {
               this.songlist.add(var5);
            }

            if(var5.getSinger().toLowerCase(Locale.getDefault()).contains(var3) && var2.equals("Singer")) {
               this.songlist.add(var5);
            }

            if(var5.getCategory().toLowerCase(Locale.getDefault()).contains(var3) && var2.equals("Category")) {
               this.songlist.add(var5);
            }
         }
      }

      this.notifyDataSetChanged();
   }

   @Override
   public int getCount() {
      return this.songlist.size();
   }

   @Override
   public Songs getItem(int var1) {
      return (Songs)this.songlist.get(var1);
   }

   @Override
   public long getItemId(int var1) {
      return (long)var1;
   }

   public View getView(int param1, View param2, ViewGroup param3) {
      // $FF: Couldn't be decompiled
   }

   class 100000000 implements OnClickListener {
      static ListViewAdapter access$0(ListViewAdapter.100000000 var0) {
         return ListViewAdapter.this;
      }

      @Override
      public void onClick(View var1) {
      }
   }

   class 100000001 implements OnClickListener {
      @Override
      public void onClick(View var1) {
         PopupMenu var2 = new PopupMenu(ListViewAdapter.this.mContext, var1);
         var2.getMenuInflater().inflate(2131099648, var2.getMenu());
         ListViewAdapter.100000000 var3 = new ListViewAdapter.100000000();
         var2.setOnMenuItemClickListener(var3);
         var2.show();
      }
   }

   class 100000000 implements OnMenuItemClickListener {
      static ListViewAdapter.100000001 access$0(ListViewAdapter.100000000 var0) {
         return ListViewAdapter.this;
      }

      public boolean onMenuItemClick(MenuItem var1) {
         Context var2 = ListViewAdapter.this.mContext;
         StringBuffer var3 = new StringBuffer();
         Toast.makeText(var2, var3.append("You Clicked : ").append(var1.getTitle()).toString(), 0).show();
         return true;
      }
   }

   class 100000002 implements OnLongClickListener {
      static ListViewAdapter access$0(ListViewAdapter.100000002 var0) {
         return ListViewAdapter.this;
      }

      @Override
      public boolean onLongClick(View var1) {
         return true;
      }
   }

   class 100000003 implements OnClickListener {
      static ListViewAdapter access$0(ListViewAdapter.100000003 var0) {
         return ListViewAdapter.this;
      }

      @Override
      public void onClick(View var1) {
         ((MainActivity)ListViewAdapter.this.mContext).openContextMenu(var1);
      }
   }

   class 100000004 implements OnClickListener {
      @Override
      public void onClick(View var1) {
         PopupMenu var2 = new PopupMenu(ListViewAdapter.this.mContext, ListViewAdapter.this.btnPopupMenu);
         var2.getMenuInflater().inflate(2131099648, var2.getMenu());
         ListViewAdapter.100000003 var3 = new ListViewAdapter.100000003();
         var2.setOnMenuItemClickListener(var3);
         var2.show();
      }
   }

   class 100000003 implements OnMenuItemClickListener {
      static ListViewAdapter.100000004 access$0(ListViewAdapter.100000003 var0) {
         return ListViewAdapter.this;
      }

      public boolean onMenuItemClick(MenuItem var1) {
         switch(var1.getItemId()) {
         case 2131165216:
         case 2131165217:
         case 2131165218:
         case 2131165219:
         default:
            Context var2 = ListViewAdapter.this.mContext;
            StringBuffer var3 = new StringBuffer();
            Toast.makeText(var2, var3.append("You Clicked : ").append(var1.getTitle()).toString(), 0).show();
            return true;
         }
      }
   }

   public class ViewHolder {
      ImageButton btnPopupMenu;
      ImageButton btnfavorite;
      TextView category;
      TextView code;
      TextView singer;
      TextView song;

      static ListViewAdapter access$0(ListViewAdapter.ViewHolder var0) {
         return ListViewAdapter.this;
      }
   }
}
