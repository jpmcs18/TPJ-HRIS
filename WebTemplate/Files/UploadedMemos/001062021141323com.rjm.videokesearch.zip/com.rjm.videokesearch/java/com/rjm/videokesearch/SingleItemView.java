package com.rjm.videokesearch;

import adrt.ADRTLogCatReader;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;

public class SingleItemView extends Activity {
   String category;
   CheckBox checkBoxFavorites;
   String code;
   String singer;
   String song;
   TextView txtcategory;
   TextView txtcode;
   TextView txtsinger;
   TextView txtsong;

   @Override
   public void onCreate(Bundle var1) {
      ADRTLogCatReader.onContext(this, "com.aide.ui");
      super.onCreate(var1);
      this.requestWindowFeature(1);
      this.setContentView(2130903051);
      Intent var3 = this.getIntent();
      this.code = var3.getStringExtra("code");
      this.song = var3.getStringExtra("song");
      this.singer = var3.getStringExtra("singer");
      this.category = var3.getStringExtra("category");
      this.txtcode = (TextView)this.findViewById(2131165211);
      this.txtsong = (TextView)this.findViewById(2131165213);
      this.txtsinger = (TextView)this.findViewById(2131165215);
      this.txtcategory = (TextView)this.findViewById(2131165217);
      this.checkBoxFavorites = (CheckBox)this.findViewById(2131165218);
      this.txtcode.setText(this.code);
      this.txtsong.setText(this.song);
      this.txtsinger.setText(this.singer);
      this.txtcategory.setText(this.category);
   }
}
