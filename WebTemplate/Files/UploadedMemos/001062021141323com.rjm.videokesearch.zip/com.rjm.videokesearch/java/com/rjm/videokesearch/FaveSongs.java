package com.rjm.videokesearch;

public class FaveSongs {
   String category;
   String code;
   int id;
   int isFavorite;
   String singer;
   String song;

   public FaveSongs() {
   }

   public FaveSongs(int var1, String var2, String var3, String var4, String var5, int var6) {
      this.id = var1;
      this.code = var2;
      this.song = var3;
      this.singer = var4;
      this.category = var5;
      this.isFavorite = var6;
   }

   public FaveSongs(String var1, String var2, String var3, String var4, int var5) {
      this.code = var1;
      this.song = var2;
      this.singer = var3;
      this.category = var4;
      this.isFavorite = var5;
   }

   public String getCategory() {
      return this.category;
   }

   public String getCode() {
      return this.code;
   }

   public int getID() {
      return this.id;
   }

   public int getIsFavorite() {
      return this.isFavorite;
   }

   public String getSinger() {
      return this.singer;
   }

   public String getSong() {
      return this.song;
   }

   public void setCategory(String var1) {
      this.category = var1;
   }

   public void setCode(String var1) {
      this.code = var1;
   }

   public void setID(int var1) {
      this.id = var1;
   }

   public void setIsFavorite(int var1) {
      this.isFavorite = var1;
   }

   public void setSinger(String var1) {
      this.singer = var1;
   }

   public void setSong(String var1) {
      this.song = var1;
   }
}
