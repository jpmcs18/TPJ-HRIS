package com.rjm.videokesearch;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import com.rjm.videokesearch.FaveSongs;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class FaveListViewAdapter extends BaseAdapter {
   ImageButton btnFavorite;
   String category = "";
   String code = "";
   private ArrayList favearraylist;
   private List favesonglist = (List)null;
   String fileName = "";
   File folder;
   FaveListViewAdapter.ViewHolder holder;
   LayoutInflater inflater;
   boolean isFave = false;
   Context mContext;
   String singer = "";
   String song = "";
   File txtDb;

   public FaveListViewAdapter(Context var1, List var2) {
      this.mContext = var1;
      this.favesonglist = var2;
      this.inflater = LayoutInflater.from(this.mContext);
      ArrayList var3 = new ArrayList();
      this.favearraylist = var3;
      this.favearraylist.addAll(var2);
   }

   // $FF: synthetic method
   static void access$S1000000(FaveListViewAdapter var0, List var1) {
      var0.favesonglist = var1;
   }

   public void createFileDb() {
      // $FF: Couldn't be decompiled
   }

   public void filter(String var1, String var2) {
      String var3 = var1.toLowerCase(Locale.getDefault());
      this.favesonglist.clear();
      if(var3.length() == 0) {
         this.favesonglist.addAll(this.favearraylist);
      } else if(var3.length() != 0 && var2.equals("Search By")) {
         Iterator var9 = ((Collection)this.favearraylist).iterator();

         label51:
         while(true) {
            FaveSongs var10;
            do {
               if(!var9.hasNext()) {
                  break label51;
               }

               var10 = (FaveSongs)var9.next();
            } while(!var10.getSong().toLowerCase(Locale.getDefault()).contains(var3) && !var10.getSinger().toLowerCase(Locale.getDefault()).contains(var3) && !var10.getCategory().toLowerCase(Locale.getDefault()).contains(var3));

            this.favesonglist.add(var10);
         }
      } else {
         Iterator var4 = ((Collection)this.favearraylist).iterator();

         while(var4.hasNext()) {
            FaveSongs var5 = (FaveSongs)var4.next();
            if(var5.getSong().toLowerCase(Locale.getDefault()).contains(var3) && var2.equals("Song")) {
               this.favesonglist.add(var5);
            }

            if(var5.getSinger().toLowerCase(Locale.getDefault()).contains(var3) && var2.equals("Singer")) {
               this.favesonglist.add(var5);
            }

            if(var5.getCategory().toLowerCase(Locale.getDefault()).contains(var3) && var2.equals("Category")) {
               this.favesonglist.add(var5);
            }
         }
      }

      this.notifyDataSetChanged();
   }

   @Override
   public int getCount() {
      return this.favesonglist.size();
   }

   @Override
   public FaveSongs getItem(int var1) {
      return (FaveSongs)this.favesonglist.get(var1);
   }

   @Override
   public long getItemId(int var1) {
      return (long)var1;
   }

   public View getView(int var1, View var2, ViewGroup var3) {
      View var4 = var2;
      if(var2 == null) {
         FaveListViewAdapter.ViewHolder var5 = new FaveListViewAdapter.ViewHolder();
         this.holder = var5;
         var4 = this.inflater.inflate(2130903048, (ViewGroup)null);
         this.holder.code = (TextView)var4.findViewById(2131165204);
         this.holder.song = (TextView)var4.findViewById(2131165208);
         this.holder.singer = (TextView)var4.findViewById(2131165209);
         this.holder.category = (TextView)var4.findViewById(2131165210);
         var4.setTag(this.holder);
      } else {
         this.holder = (FaveListViewAdapter.ViewHolder)var2.getTag();
      }

      this.holder.code.setText(((FaveSongs)this.favesonglist.get(var1)).getCode());
      this.holder.song.setText(((FaveSongs)this.favesonglist.get(var1)).getSong());
      this.holder.singer.setText(((FaveSongs)this.favesonglist.get(var1)).getSinger());
      this.holder.category.setText(((FaveSongs)this.favesonglist.get(var1)).getCategory());
      FaveListViewAdapter.100000000 var7 = new FaveListViewAdapter.100000000(var1);
      var4.setOnClickListener(var7);
      this.btnFavorite = (ImageButton)var4.findViewById(2131165203);
      ImageButton var8 = this.btnFavorite;
      FaveListViewAdapter.100000001 var9 = new FaveListViewAdapter.100000001(var1);
      var8.setOnClickListener(var9);
      return var4;
   }

   class 100000000 implements OnClickListener {
      private final int val$position;

      _00000000/* $FF was: 100000000*/(int var2) {
         this.val$position = var2;
      }

      static FaveListViewAdapter access$0(FaveListViewAdapter.100000000 var0) {
         return FaveListViewAdapter.this;
      }

      @Override
      public void onClick(View var1) {
         Context var2 = FaveListViewAdapter.this.mContext;

         Class var5;
         try {
            var5 = Class.forName("com.rjm.videokesearch.SingleItemView");
         } catch (ClassNotFoundException var7) {
            NoClassDefFoundError var4 = new NoClassDefFoundError(var7.getMessage());
            throw var4;
         }

         Intent var6 = new Intent(var2, var5);
         var6.putExtra("code", ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getCode());
         var6.putExtra("song", ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getSong());
         var6.putExtra("singer", ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getSinger());
         var6.putExtra("category", ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getCategory());
         FaveListViewAdapter.this.mContext.startActivity(var6);
      }
   }

   class 100000001 implements OnClickListener {
      private final int val$position;

      _00000001/* $FF was: 100000001*/(int var2) {
         this.val$position = var2;
      }

      static FaveListViewAdapter access$0(FaveListViewAdapter.100000001 var0) {
         return FaveListViewAdapter.this;
      }

      @Override
      public void onClick(View var1) {
         var1.setBackgroundResource(2130837507);
         FaveListViewAdapter.this.code = ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getCode();
         FaveListViewAdapter.this.song = ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getSong();
         FaveListViewAdapter.this.singer = ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getSinger();
         FaveListViewAdapter.this.category = ((FaveSongs)FaveListViewAdapter.this.favesonglist.get(this.val$position)).getCategory();
         FaveListViewAdapter.this.favesonglist.remove(FaveListViewAdapter.this.getItem(this.val$position));
         FaveListViewAdapter.this.notifyDataSetChanged();
         FaveListViewAdapter.this.createFileDb();
      }
   }

   public class ViewHolder {
      ImageButton btnFavorite;
      ImageButton btnPopupMenu;
      TextView category;
      TextView code;
      TextView singer;
      TextView song;

      static FaveListViewAdapter access$0(FaveListViewAdapter.ViewHolder var0) {
         return FaveListViewAdapter.this;
      }
   }
}
