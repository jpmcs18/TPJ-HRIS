package com.rjm.videokesearch;

import adrt.ADRTLogCatReader;
import android.os.Bundle;
import android.preference.PreferenceActivity;

public class Settings extends PreferenceActivity {
   @Override
   public void onCreate(Bundle var1) {
      ADRTLogCatReader.onContext(this, "com.aide.ui");
      super.onCreate(var1);
      this.setContentView(2130903050);
   }
}
