package com.rjm.videokesearch;

import adrt.ADRTLogCatReader;
import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.widget.TextView;

public class About extends Activity {
   TextView aboutAuthor;
   TextView aboutBuild;
   TextView aboutCreator;
   TextView aboutTitle;
   TextView aboutVersion;

   @Override
   public void onCreate(Bundle var1) {
      ADRTLogCatReader.onContext(this, "com.aide.ui");
      super.onCreate(var1);
      this.requestWindowFeature(1);
      this.setContentView(2130903040);
      this.aboutTitle = (TextView)this.findViewById(2131165185);
      this.aboutVersion = (TextView)this.findViewById(2131165188);
      this.aboutBuild = (TextView)this.findViewById(2131165186);
      this.aboutAuthor = (TextView)this.findViewById(2131165187);
      this.aboutCreator = (TextView)this.findViewById(2131165189);
      PackageManager var3 = this.getPackageManager();

      try {
         PackageInfo var5 = var3.getPackageInfo(this.getPackageName(), 0);
         String var6 = var5.versionName;
         int var7 = var5.versionCode;
         String var8 = var5.applicationInfo.loadLabel(this.getPackageManager()).toString();
         TextView var9 = this.aboutTitle;
         StringBuffer var10 = new StringBuffer();
         StringBuffer var11 = new StringBuffer();
         StringBuffer var12 = new StringBuffer();
         StringBuffer var13 = new StringBuffer();
         StringBuffer var14 = new StringBuffer();
         var9.setText(var10.append(var11.append(var12.append(var13.append(var14.append(var8).append(" ").toString()).append(var6).toString()).append(" build (").toString()).append(var7).toString()).append(")").toString());
         this.aboutBuild.setText("© 2017 RJM Tech, Inc.");
         this.aboutVersion.setText("All rights reserved");
         TextView var15 = this.aboutAuthor;
         StringBuffer var16 = new StringBuffer();
         var15.setText(var16.append(var8).append(" is a trademark of RJM Tech, Inc.").toString());
         this.aboutCreator.setText("Raff Julius Olazo Martinez");
      } catch (NameNotFoundException var17) {
         ;
      }
   }
}
