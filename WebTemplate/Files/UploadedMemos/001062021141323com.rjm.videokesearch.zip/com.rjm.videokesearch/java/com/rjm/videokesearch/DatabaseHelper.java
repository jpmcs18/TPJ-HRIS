package com.rjm.videokesearch;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.widget.Toast;
import com.rjm.videokesearch.FaveSongs;
import com.rjm.videokesearch.Songs;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
   public static final String CATEGORY = "category";
   public static final String CODE = "code";
   public static final String DATABASE_NAME = "videokesearch";
   public static final String ID = "id";
   public static final String ISFAVORITE = "isfavorite";
   public static final String SINGER = "singer";
   public static final String SONG = "song";
   public static final String TABLE_SONGS = "tblSongs";
   public SQLiteDatabase db = this.getWritableDatabase();
   Context mContext;

   public DatabaseHelper(Context var1) {
      super(var1, "videokesearch", (CursorFactory)null, 5);
      this.mContext = var1;
   }

   void addSongs(Songs var1) {
      SQLiteDatabase var2 = this.getWritableDatabase();
      ContentValues var3 = new ContentValues();
      var3.put("code", var1.getCode());
      var3.put("song", var1.getSong());
      var3.put("singer", var1.getSinger());
      var3.put("category", var1.getCategory());
      int var4 = var1.getIsFavorite();
      Integer var5 = new Integer(var4);
      var3.put("isfavorite", var5);
      var2.insert("tblSongs", (String)null, var3);
      var2.close();
   }

   public int addToFavorites(int var1, int var2) {
      SQLiteDatabase var3 = this.getWritableDatabase();
      ContentValues var4 = new ContentValues();
      Integer var5 = new Integer(var2);
      var4.put("isfavorite", var5);
      StringBuffer var6 = new StringBuffer();
      String var7 = var6.append("id").append(" = ?").toString();
      String[] var8 = new String[]{String.valueOf(var1)};
      return var3.update("tblSongs", var4, var7, var8);
   }

   public void deleteSongs(int var1) {
      try {
         SQLiteDatabase var3 = this.getWritableDatabase();
         StringBuffer var4 = new StringBuffer();
         String var5 = var4.append("id").append(" = ?").toString();
         String[] var6 = new String[]{String.valueOf(var1)};
         var3.delete("tblSongs", var5, var6);
         var3.close();
         Toast.makeText(this.mContext, "Song deleted", 0).show();
      } catch (Exception var7) {
         Toast.makeText(this.mContext, "Error deleting song", 0).show();
      }
   }

   public List getAllFavoriteSongs() {
      ArrayList var1 = new ArrayList();
      StringBuffer var2 = new StringBuffer();
      StringBuffer var3 = new StringBuffer();
      StringBuffer var4 = new StringBuffer();
      StringBuffer var5 = new StringBuffer();
      String var6 = var2.append(var3.append(var4.append(var5.append("SELECT  * FROM ").append("tblSongs").toString()).append(" WHERE ").toString()).append("isfavorite").toString()).append(" = 1").toString();
      Cursor var7 = this.getWritableDatabase().rawQuery(var6, (String[])null);
      if(var7.moveToFirst()) {
         do {
            FaveSongs var8 = new FaveSongs();
            var8.setID(Integer.parseInt(var7.getString(0)));
            var8.setCode(var7.getString(1));
            var8.setSong(var7.getString(2));
            var8.setSinger(var7.getString(3));
            var8.setCategory(var7.getString(4));
            var8.setIsFavorite(Integer.parseInt(var7.getString(5)));
            var1.add(var8);
         } while(var7.moveToNext());
      }

      return var1;
   }

   public List getAllSongs() {
      ArrayList var1 = new ArrayList();
      StringBuffer var2 = new StringBuffer();
      String var3 = var2.append("SELECT  * FROM ").append("tblSongs").toString();
      Cursor var4 = this.getWritableDatabase().rawQuery(var3, (String[])null);
      if(var4.moveToFirst()) {
         do {
            Songs var5 = new Songs();
            var5.setID(Integer.parseInt(var4.getString(0)));
            var5.setCode(var4.getString(1));
            var5.setSong(var4.getString(2));
            var5.setSinger(var4.getString(3));
            var5.setCategory(var4.getString(4));
            var5.setIsFavorite(Integer.parseInt(var4.getString(5)));
            var1.add(var5);
         } while(var4.moveToNext());
      }

      return var1;
   }

   Songs getSong(int var1) {
      SQLiteDatabase var2 = this.getReadableDatabase();
      String[] var3 = new String[]{"id", "code", "song", "singer", "category", "isfavorite"};
      StringBuffer var4 = new StringBuffer();
      String var5 = var4.append("id").append("=?").toString();
      String[] var6 = new String[]{String.valueOf(var1)};
      Cursor var7 = var2.query("tblSongs", var3, var5, var6, (String)null, (String)null, (String)null, (String)null);
      if(var7 != null) {
         var7.moveToFirst();
      }

      Songs var8 = new Songs(Integer.parseInt(var7.getString(0)), var7.getString(1), var7.getString(2), var7.getString(3), var7.getString(4), var7.getInt(5));
      return var8;
   }

   public int getSongsCount() {
      StringBuffer var1 = new StringBuffer();
      String var2 = var1.append("SELECT  * FROM ").append("tblSongs").toString();
      Cursor var3 = this.getReadableDatabase().rawQuery(var2, (String[])null);
      var3.close();
      return var3.getCount();
   }

   @Override
   public void onCreate(SQLiteDatabase var1) {
      StringBuffer var2 = new StringBuffer();
      StringBuffer var3 = new StringBuffer();
      StringBuffer var4 = new StringBuffer();
      StringBuffer var5 = new StringBuffer();
      StringBuffer var6 = new StringBuffer();
      StringBuffer var7 = new StringBuffer();
      StringBuffer var8 = new StringBuffer();
      StringBuffer var9 = new StringBuffer();
      StringBuffer var10 = new StringBuffer();
      StringBuffer var11 = new StringBuffer();
      StringBuffer var12 = new StringBuffer();
      StringBuffer var13 = new StringBuffer();
      StringBuffer var14 = new StringBuffer();
      StringBuffer var15 = new StringBuffer();
      var1.execSQL(var2.append(var3.append(var4.append(var5.append(var6.append(var7.append(var8.append(var9.append(var10.append(var11.append(var12.append(var13.append(var14.append(var15.append("CREATE TABLE ").append("tblSongs").toString()).append("(").toString()).append("id").toString()).append(" INTEGER PRIMARY KEY,").toString()).append("code").toString()).append(" TEXT,").toString()).append("song").toString()).append(" TEXT,").toString()).append("singer").toString()).append(" TEXT,").toString()).append("category").toString()).append(" TEXT,").toString()).append("isfavorite").toString()).append(" INTEGER)").toString());
      Toast.makeText(this.mContext, "sqlite!", 0).show();
   }

   @Override
   public void onUpgrade(SQLiteDatabase var1, int var2, int var3) {
      StringBuffer var4 = new StringBuffer();
      var1.execSQL(var4.append("DROP TABLE IF EXISTS ").append("tblSongs").toString());
      this.onCreate(var1);
   }

   public int updateSong(Songs var1) {
      SQLiteDatabase var2 = this.getWritableDatabase();
      ContentValues var3 = new ContentValues();
      var3.put("code", var1.getCode());
      var3.put("song", var1.getSong());
      var3.put("singer", var1.getSinger());
      var3.put("category", var1.getCategory());
      int var4 = var1.getIsFavorite();
      Integer var5 = new Integer(var4);
      var3.put("isfavorite", var5);
      StringBuffer var6 = new StringBuffer();
      String var7 = var6.append("id").append(" = ?").toString();
      String[] var8 = new String[]{String.valueOf(var1.getID())};
      return var2.update("tblSongs", var3, var7, var8);
   }
}
