package adrt;

import adrt.ADRTSender;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;

public class ADRTLogCatReader implements Runnable {
   private static Context context;

   public static void onContext(Context var0, String var1) {
      if(context == null) {
         context = var0.getApplicationContext();
         boolean var2;
         if((2 & var0.getApplicationInfo().flags) != 0) {
            var2 = true;
         } else {
            var2 = false;
         }

         if(var2) {
            try {
               var0.getPackageManager().getPackageInfo(var1, 128);
            } catch (NameNotFoundException var7) {
               return;
            }

            ADRTSender.onContext(context, var1);
            ADRTLogCatReader var5 = new ADRTLogCatReader();
            Thread var6 = new Thread(var5, "LogCat");
            var6.start();
         }
      }
   }

   public void run() {
      // $FF: Couldn't be decompiled
   }
}
