package adrt;

import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;

public class ADRTSender {
   private static Context context;
   private static String debuggerPackageName;

   public static void onContext(Context var0, String var1) {
      context = var0;
      debuggerPackageName = var1;
   }

   public static void sendBreakpointHit(String var0, ArrayList var1, ArrayList var2, ArrayList var3, ArrayList var4, ArrayList var5, ArrayList var6) {
      Intent var7 = new Intent();
      var7.setPackage(debuggerPackageName);
      var7.setAction("com.adrt.BREAKPOINT_HIT");
      var7.putExtra("package", var0);
      var7.putExtra("variables", var1);
      var7.putExtra("variableValues", var2);
      var7.putExtra("variableKinds", var3);
      var7.putExtra("stackMethods", var4);
      var7.putExtra("stackLocations", var5);
      var7.putExtra("stackLocationKinds", var6);
      context.sendBroadcast(var7);
   }

   public static void sendConnect(String var0) {
      Intent var1 = new Intent();
      var1.setPackage(debuggerPackageName);
      var1.setAction("com.adrt.CONNECT");
      var1.putExtra("package", var0);
      context.sendBroadcast(var1);
   }

   public static void sendFields(String var0, String var1, ArrayList var2, ArrayList var3, ArrayList var4) {
      Intent var5 = new Intent();
      var5.setPackage(debuggerPackageName);
      var5.setAction("com.adrt.FIELDS");
      var5.putExtra("package", var0);
      var5.putExtra("path", var1);
      var5.putExtra("fields", var2);
      var5.putExtra("fieldValues", var3);
      var5.putExtra("fieldKinds", var4);
      context.sendBroadcast(var5);
   }

   public static void sendLogcatLines(String[] var0) {
      Intent var1 = new Intent();
      var1.setPackage(debuggerPackageName);
      var1.setAction("com.adrt.LOGCAT_ENTRIES");
      var1.putExtra("lines", var0);
      context.sendBroadcast(var1);
   }

   public static void sendStop(String var0) {
      Intent var1 = new Intent();
      var1.setPackage(debuggerPackageName);
      var1.setAction("com.adrt.STOP");
      var1.putExtra("package", var0);
      context.sendBroadcast(var1);
   }
}
